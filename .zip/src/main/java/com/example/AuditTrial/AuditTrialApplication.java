package com.example.AuditTrial;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication

public class AuditTrialApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuditTrialApplication.class, args);
	}

}
