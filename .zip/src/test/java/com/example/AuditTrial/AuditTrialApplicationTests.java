package com.example.AuditTrial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditTrialApplicationTests {

	@Test
	void contextLoads() {
	}

}
